﻿using UnityEngine;
using System.Collections;

public class cannon_rotation : Entities
{
    //https://unity3d.com/learn/tutorials/topics/2d-game-creation/top-down-2d-game-basics
    // Use this for initialization
    //public float speed;

    // Update is called once per frame
    void FixedUpdate () {
        var mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Quaternion rot = Quaternion.LookRotation(transform.position - mousePosition, Vector3.forward);
        transform.rotation = rot;
        transform.eulerAngles = new Vector3(0, 0, transform.eulerAngles.z);
       
    }
}
