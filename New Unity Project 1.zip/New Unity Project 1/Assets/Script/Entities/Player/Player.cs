﻿using UnityEngine;
using System.Collections;

public class Player : Entities
{
   
	// Use this for initialization
	void Start () {
        transform.eulerAngles = new Vector3(0, 0, transform.eulerAngles.z);
    }
	
	// Update is called once per frame
	void Update () {
       
        //facing down and moving down
        if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow))
        {
            GetComponent<Rigidbody2D>().transform.rotation = Quaternion.Euler(0, 0, 180);
            GetComponent<Rigidbody2D>().transform.position += Vector3.down * speed * Time.deltaTime;
        }
        //facing up and moving up
        //because this is after the down when both button are pressed the default postiong is up
        if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow))
        {
            GetComponent<Rigidbody2D>().transform.rotation = Quaternion.Euler(0, 0, 0);
            GetComponent<Rigidbody2D>().transform.position += Vector3.up * speed * Time.deltaTime;
        }
        //facing left and moving left
        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
        {
            GetComponent<Rigidbody2D>().transform.rotation = Quaternion.Euler(0, 0, 90);
            GetComponent<Rigidbody2D>().transform.position += Vector3.left * speed * Time.deltaTime;
        }
        //facing right and moving right
        if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow))
        {
            GetComponent<Rigidbody2D>().transform.rotation = Quaternion.Euler(0, 0, -90);
            GetComponent<Rigidbody2D>().transform.position += Vector3.right * speed * Time.deltaTime;
        }
        //for facing north-west
        if ((Input.GetKey(KeyCode.W) && Input.GetKey(KeyCode.A)) || (Input.GetKey(KeyCode.UpArrow) && Input.GetKey(KeyCode.LeftArrow)))
        {
            GetComponent<Rigidbody2D>().transform.rotation = Quaternion.Euler(0, 0, 45);
        }
        //facing north-east
        if ((Input.GetKey(KeyCode.W) && Input.GetKey(KeyCode.D)) || (Input.GetKey(KeyCode.UpArrow) && Input.GetKey(KeyCode.RightArrow)))
        {
            GetComponent<Rigidbody2D>().transform.rotation = Quaternion.Euler(0, 0, -45);
        }
        //facing south-west
        if ((Input.GetKey(KeyCode.S) && Input.GetKey(KeyCode.A)) || (Input.GetKey(KeyCode.DownArrow) && Input.GetKey(KeyCode.LeftArrow)))
        {
            GetComponent<Rigidbody2D>().transform.rotation = Quaternion.Euler(0, 0, 135);
        }
        //facing south-east
        if ((Input.GetKey(KeyCode.S) && Input.GetKey(KeyCode.D)) || (Input.GetKey(KeyCode.DownArrow) && Input.GetKey(KeyCode.RightArrow)))
        {
            GetComponent<Rigidbody2D>().transform.rotation = Quaternion.Euler(0, 0, -135);
        }
        //if up east and west are pressed at the same time the tank is facing up and moving forward
        //without this code the tank will face eith north-east or north-west while moving forward
        if ((Input.GetKey(KeyCode.W) && Input.GetKey(KeyCode.A) && Input.GetKey(KeyCode.D)))
        {
            GetComponent<Rigidbody2D>().transform.rotation = Quaternion.Euler(0, 0, 0);
        }
        //if up east and west are pressed at the same time the tank is facing down and moving backwards
        //without this code the tank will face eith south-east or south-west while moving backwards
        if ((Input.GetKey(KeyCode.S) && Input.GetKey(KeyCode.D) && Input.GetKey(KeyCode.A)))
        {
            GetComponent<Rigidbody2D>().transform.rotation = Quaternion.Euler(0, 0, 180);
        }

    }

}
